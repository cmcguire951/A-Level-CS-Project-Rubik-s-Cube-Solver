from cube import *
moves = 0
solved = False

print(CubeState)

DesiredState = np.zeros((6,3,3), dtype=str)

for i in range (0,6):
    for f in range (0,3):
        if i==0:
            DesiredState[i,0,f] = "White"
            DesiredState[i,1,f] = "White"
            DesiredState[i,2,f] = "White"                    
        if i==1:
            DesiredState[i,0,f] = "Green"
            DesiredState[i,1,f] = "Green"
            DesiredState[i,2,f] = "Green"                    
        if i==2:
            DesiredState[i,0,f] = "Red"
            DesiredState[i,1,f] = "Red"
            DesiredState[i,2,f] = "Red"                    
        if i==3:
            DesiredState[i,0,f] = "Blue"
            DesiredState[i,1,f] = "Blue"
            DesiredState[i,2,f] = "Blue"                    
        if i==4:
            DesiredState[i,0,f] = "Orange"
            DesiredState[i,1,f] = "Orange"
            DesiredState[i,2,f] = "Orange"                    
        if i==5:
            DesiredState[i,0,f] = "Yellow"
            DesiredState[i,1,f] = "Yellow"
            DesiredState[i,2,f] = "Yellow"

print(DesiredState)



corners = np.empty((9,5), dtype=object)
edges = np.empty((13,3), dtype=object)

corners[0,0],corners[0,1],corners[0,2],corners[0,3],corners[0,4] = 'Piece No.','Front Color','Top/Bottom Color','Side Color','Orientation'

edges[0,0],edges[0,1],edges[0,2] = 'Piece No.','Front','Side'

def cube_update():
    ## Defining the  8 corners
    corners[1,0], corners[1,1], corners[1,2], corners[1,3], corners[1,4] = 1, CubeState[2,2,0], CubeState[5,0,0], CubeState[1,2,2], 'Front-Front'
    corners[2,0], corners[2,1], corners[2,2], corners[2,3], corners[2,4] = 3, CubeState[1,2,0], CubeState[5,2,0], CubeState[4,2,2], 'Front-Left'
    corners[3,0], corners[3,1], corners[3,2], corners[3,3], corners[3,4] = 7, CubeState[2,0,0], CubeState[0,2,0], CubeState[1,0,2], 'Front-Front'
    corners[4,0], corners[4,1], corners[4,2], corners[4,3], corners[4,4] = 9, CubeState[1,0,0], CubeState[0,0,0], CubeState[4,0,2], 'Front-Left'
    corners[5,0], corners[5,1], corners[5,2], corners[5,3], corners[5,4] = 19, CubeState[2,2,2], CubeState[5,0,2], CubeState[3,2,0], 'Front-Front'
    corners[6,0], corners[6,1], corners[6,2], corners[6,3], corners[6,4] = 21, CubeState[3,2,2], CubeState[5,2,2], CubeState[4,2,0], 'Front-Right'
    corners[7,0], corners[7,1], corners[7,2], corners[7,3], corners[7,4] = 25, CubeState[2,0,2], CubeState[0,2,2], CubeState[3,0,0], 'Front-Front'
    corners[8,0], corners[8,1], corners[8,2], corners[8,3], corners[8,4] = 27, CubeState[3,0,2], CubeState[0,0,2], CubeState[4,0,0], 'Front-Right'

    ## Defining the 12 edges
    edges[1,0], edges[1,1], edges[1,2] = 2, CubeState[1,2,1], CubeState[5,1,0]
    edges[2,0], edges[2,1], edges[2,2] = 4, CubeState[2,1,0], CubeState[1,1,2]
    edges[3,0], edges[3,1], edges[3,2] = 6, CubeState[1,1,0], CubeState[4,1,2]
    edges[4,0], edges[4,1], edges[4,2] = 8, CubeState[1,0,1], CubeState[0,1,0]
    edges[5,0], edges[5,1], edges[5,2] = 10, CubeState[2,2,1], CubeState[5,0,1]
    edges[6,0], edges[6,1], edges[6,2] = 12, CubeState[4,2,1], CubeState[5,2,1]
    edges[7,0], edges[7,1], edges[7,2] = 16, CubeState[2,0,1], CubeState[0,2,1]
    edges[8,0], edges[8,1], edges[8,2] = 18, CubeState[4,0,1], CubeState[0,0,1]
    edges[9,0], edges[9,1], edges[9,2] = 20, CubeState[3,2,1], CubeState[5,1,2]
    edges[10,0], edges[10,1], edges[10,2] = 22, CubeState[2,1,2], CubeState[3,1,0]
    edges[11,0], edges[11,1], edges[11,2] = 24, CubeState[3,1,2], CubeState[4,1,0]
    edges[12,0], edges[12,1], edges[12,2] = 26, CubeState[3,0,1], CubeState[0,1,2]

cube_update()

#print(edges)

def first_layer():
    ## Building the white cross
    for i in range(1,13):
        CorrectPlace = False
        if 'W' in edges[i]:
            if 'G' in edges[i]:
                if edges[i,1] == 'G':
                    while CorrectPlace == False:
                        if edges[i,0] == 8:
                            CorrectPlace = True
                            print('correct place')
                        if edges[i,0] == 2:
                            L()
                            L()
                            CorrectPlace = True
                            print('Correct Place')
                        if edges[i,0] == 10:
                            Dp()
                            L()
                            L()
                            CorrectPlace = True
                            print('Correct Place')
                        if edges[i,0] == 20:
                            D()
                            D()
                            L()
                            L()
                            CorrectPlace = True
                            print('Correct Place')
                        if edges[i,0] == 12:
                            Dp()
                            L()
                            L()
                            CorrectPlace = True
                            print('Correct Place')
                        if edges[i,0] == 6:
                            L()
                            CorrectPlace = True
                            Print('Correct Place')
                
                


#first_layer()


            
            

            
                
            

        

#first_layer()
    

