from ursina import *

class Cube(Ursina):
    def __init__(self):
        super().__init__()
        window.fullscreen = True
        EditorCamera()                      # Creates original scene
        camera.world_position = (0,0,-40)
        self.model, self.texture = 'models/cubelet','textures/cublet texture'  # Defines the model and texture to be used throughout
        self.load()

    def load(self):
        self.cubelet_pos()
        self.parent = Entity(model='cube', texture = 'white_cube')
        self.cubes = [Entity(parent = self.parent, model=self.model, texture=self.texture, position=pos, rotation=(0,-90,0)) for pos in self.sidepos] # Sets the model, texture and position of cubelets to be created
        self.rotation_axes = {'L':'x', 'R':'x','U':'y','D':'y','F':'z','B':'z'}
        self.cubelet_side_pos = {'L': self.L, 'D': self.D, 'B': self.B, 'F': self.F, 'R': self.R, 'U': self.U}
        self.rot = 0

        self.animation_time = 0.5

    def rotate(self, sidename):
        cube_position = self.cubelet_side_pos[sidename]
        rotation_axis = self.rotation_axes[sidename]
        self.parent_to_scene()
        for cube in self.cubes:
            if cube.position in cube_position:
                cube.parent = self.parent
                eval(f'self.parent.animate_rotation_{rotation_axis}(90, duration=self.animation_time)')
        

    def parent_to_scene(self):
        for cube in self.cubes:
            if cube.parent == self.parent:
                world_pos, world_rot = round(cube.world_position, 1), cube.world_rotation  # Parents individual parts of the cube to the scene instead of the center so that the whole cube doesn't move but individual parts do
                cube.parent = scene
                cube.position, cube.rotation = world_pos, world_rot
        self.parent.rotation = 0
                

    def cubelet_pos(self):
        self.L = {Vec3(-2, y, z) for y in range(-2,4,2) for z in range(-2,4,2)}
        self.D = {Vec3(x, -2, z) for x in range(-2,4,2) for z in range(-2,4,2)}  # Creates the L and B sides
        self.B = {Vec3(x, y, 2) for x in range(-2,4,2) for y in range(-2,4,2)}
        self.F = {Vec3(x, y, -2) for x in range(-2,4,2) for y in range(-2,4,2)}
        self.R = {Vec3(2, y, z) for y in range(-2,4,2) for z in range(-2,4,2)}
        self.U = {Vec3(x, 2, z) for x in range(-2,4,2) for z in range(-2,4,2)}
        self.sidepos = self.L | self.D | self.B | self.F | self.R | self.U   # Stores the positions of the L and D sides

    def left(self):
        self.rotate('L')
    def lower(self):
        self.rotate('D')
    def back(self):
        self.rotate('B')
    def front(self):
        self.rotate('F')
    def right(self):
        self.rotate('R')
    def upper(self):
        self.rotate('U')

    def input(self, key):
        if key == 'l':
            self.left()
        if key == 'd':
            self.lower()
        if key == 'b':
            self.back()
        if key == 'f':
            self.front()
        if key == 'r':
            self.right()
        if key == 'u':
            self.upper()
        super().input(key)
            
if __name__ == '__main__':
    game = Cube()
    game.run()
