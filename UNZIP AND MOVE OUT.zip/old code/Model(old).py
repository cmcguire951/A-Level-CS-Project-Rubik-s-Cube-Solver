from ursina import *
import time
import numpy as np
from cube import *
import time

app = Ursina()

origin = Entity() # creates an empty entity that the camera orbits around

cubelets = [None]*27
i = 0
cubelet_pos = np.zeros((27,4), dtype=int)               # sets initial arrays to store current position and rotation of cubelets
cubelet_rotation = np.zeros((27,4), dtype=int)

global a
global b
global c

a=0
b=-90   # sets starting values for the orientation
c=0


for x in range(-2,4,2):
        for y in range(-2,4,2):
                for z in range(-2,4,2):
                        cubelets[i] = Entity(model='models/cubelet', texture='cublet texture.png', position=Vec3(x, y, z), rotation=(a,b,c))
                        
                        cubelet_pos[i,0] = x
                        cubelet_pos[i,1] = y
                        cubelet_pos[i,2] = z
                        cubelet_pos[i,3] = i
                                                                # creates 27 cube entities and stores each position and rotation in the array
                        cubelet_rotation[i,0] = a
                        cubelet_rotation[i,1] = b
                        cubelet_rotation[i,2] = c
                        cubelet_rotation[i,3]= i
                        
                        i += 1


Entity(model='xyz', texture='xyz', scale=2)

camera.parent = origin
camera.z = -50  # sets initial position of the camera

temps = np.zeros((9,3), dtype=int)


#cubelets[6].model ='cube'
#cubelets[6].texture ='white_cube'                

def input(key):
        if key=='u':
                U()
                print(cubelet_pos)

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(-2,2,-2):
                                found = True
                        else:
                                i+=1
                LowerLeft = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(0,2,-2):
                                found = True
                        else:
                                i+=1
                LowerMiddle = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,2,-2):
                                found = True
                        else:
                                i+=1
                LowerRight = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(-2,2,0):
                                found = True
                        else:
                                i+=1
                MiddleLeft = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(0,2,0):
                                found = True
                        else:
                                i+=1
                Center = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,2,0):
                                found = True
                        else:
                                i+=1
                MiddleRight = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(-2,2,2):
                                found = True
                        else:
                                i+=1
                UpperLeft = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(0,2,2):
                                found = True
                        else:
                                i+=1
                UpperMiddle = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position  == Vec3(2,2,2):
                                found = True
                        else:
                                i+=1
                UpperRight = i

                C = cubelets[Center].position 
                UM = cubelets[UpperMiddle].position  
                UL = cubelets[UpperLeft].position  
                UR = cubelets[UpperRight].position 
                LM = cubelets[MiddleLeft].position  #Sets the state of the face to temp variables
                RM = cubelets[MiddleRight].position 
                BL = cubelets[LowerLeft].position 
                BM = cubelets[LowerMiddle].position 
                BR = cubelets[LowerRight].position

                cubelets[Center].position = C
                cubelets[LowerMiddle].position = LM
                cubelets[LowerRight].position = BL
                cubelets[LowerLeft].position = UL
                cubelets[MiddleRight].position = BM         #Transposes the face
                cubelets[MiddleLeft].position = UM
                cubelets[UpperRight].position = BR
                cubelets[UpperMiddle].position = RM
                cubelets[UpperLeft].position = UR

                cubelets[Center].rotation_y += 90
                cubelets[UpperMiddle].rotation_y += 90 
                cubelets[UpperLeft].rotation_y += 90 
                cubelets[UpperRight].rotation_y += 90 
                cubelets[MiddleLeft].rotation_y += 90  #Rotates the individual cubes
                cubelets[MiddleRight].rotation_y += 90 
                cubelets[LowerLeft].rotation_y += 90 
                cubelets[LowerMiddle].rotation_y += 90 
                cubelets[LowerRight].rotation_y += 90

                for a in range(0,27):
                        cubelet_pos[a,0] = cubelets[a].x
                        cubelet_pos[a,1] = cubelets[a].y
                        cubelet_pos[a,2] = cubelets[a].z
                        cubelet_pos[a,3] = a

        if key=='r':
                print(cubelet_pos)

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,-2,-2):
                                found = True
                        else:
                                i+=1
                LowerLeft = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,-2,0):
                                found = True
                        else:
                                i+=1
                LowerMiddle = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,-2,2):
                                found = True
                        else:
                                i+=1
                LowerRight = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,0,-2):
                                found = True
                        else:
                                i+=1
                MiddleLeft = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,0,0):
                                found = True
                        else:
                                i+=1
                Center = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,0,2):
                                found = True
                        else:
                                i+=1
                MiddleRight = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,2,-2):
                                found = True
                        else:
                                i+=1
                UpperLeft = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position == Vec3(2,2,0):
                                found = True
                        else:
                                i+=1
                UpperMiddle = i

                i=0
                found = False
                while found == False:
                        if cubelets[i].position  == Vec3(2,2,2):
                                found = True
                        else:
                                i+=1
                UpperRight = i

                C = cubelets[Center].position 
                UM = cubelets[UpperMiddle].position  
                UL = cubelets[UpperLeft].position  
                UR = cubelets[UpperRight].position 
                LM = cubelets[MiddleLeft].position  #Sets the state of the face to temp variables
                RM = cubelets[MiddleRight].position 
                BL = cubelets[LowerLeft].position 
                BM = cubelets[LowerMiddle].position 
                BR = cubelets[LowerRight].position

                cubelets[Center].position = C
                cubelets[LowerMiddle].position = LM
                cubelets[LowerRight].position = BL
                cubelets[LowerLeft].position = UL
                cubelets[MiddleRight].position = BM         #Transposes the face
                cubelets[MiddleLeft].position = UM
                cubelets[UpperRight].position = BR
                cubelets[UpperMiddle].position = RM
                cubelets[UpperLeft].position = UR

                cubelets[Center].rotation_z += 90
                cubelets[UpperMiddle].rotation_z += 90 
                cubelets[UpperLeft].rotation_z += 90 
                cubelets[UpperRight].rotation_z += 90 
                cubelets[MiddleLeft].rotation_z += 90  #Rotates the individual cubes
                cubelets[MiddleRight].rotation_z += 90 
                cubelets[LowerLeft].rotation_z += 90 
                cubelets[LowerMiddle].rotation_z += 90 
                cubelets[LowerRight].rotation_z += 90

                for a in range(0,27):
                        cubelet_pos[a,0] = cubelets[a].x
                        cubelet_pos[a,1] = cubelets[a].y
                        cubelet_pos[a,2] = cubelets[a].z
                        cubelet_pos[a,3] = a

                


                        
                        



def update():
        origin.rotation_y += (mouse.velocity[0] * mouse.left *100)              # allows for the camera to be moved by the mouse
        origin.rotation_x -= (mouse.velocity[1] * mouse.left * 100)

        


app.run()



