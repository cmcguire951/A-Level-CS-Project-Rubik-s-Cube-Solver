from cube import *
from solving import *

while True:
    move = input('What move would you like to do? Includes prime moves such as Up')
    move = move.lower()
    if move == 'u':
        U()
        cube_update()
    if move == 'f':
        F()
        cube_update()
    if move == 'd':
        D()
        cube_update()
    if move == 'b':
        B()
        cube_update()
    if move == 'r':
        R()
        cube_update()
    if move == 'l':
        L()
        cube_update()
    if move == 'up':
        Up()
        cube_update()
    if move == 'fp':
        Fp()
        cube_update()
    if move == 'dp':
        Dp()
        cube_update()
    if move == 'bp':
        Bp()
        cube_update()
    if move == 'rp':
        Rp()
        cube_update()
    if move == 'lp':
        Lp()
        cube_update()
    
    print('')
    print('')
    print(CubeState)
    print('')
    print('')
    #print(edges)
    
        
