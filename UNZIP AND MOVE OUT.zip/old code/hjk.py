import os

print(help('rubik_solver'))
